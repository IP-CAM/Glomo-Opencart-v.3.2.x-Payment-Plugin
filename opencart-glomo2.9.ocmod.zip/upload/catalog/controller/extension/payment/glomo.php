<?php
class ControllerExtensionPaymentGlomo extends Controller {

  const API_URL = "https://apis.glomoapp.com/v1/";
  const API_INI = "/account/debit/initiate";
  const API_VALIDER = "/account/debit/valid";
  const API_RESEND = "/account/operation/code/sms/resend";

  public function index() {
    $this->language->load('extension/payment/glomo');
    $this->load->model('checkout/order');
    $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
    $data['action'] =$this->url->link('extension/payment/glomo/initiatTrans');
    $data['action2'] =$this->url->link('extension/payment/glomo/validerPayment');
    $data['button_confirm'] = $this->language->get('button_confirm');
    $data['token_error'] = $this->language->get('token_error');
    $data['order_id'] = $this->session->data['order_id'];
    $data['amount'] = $order_info['total'];
    $data['payment_glomo_label'] = $this->config->get('payment_glomo_label');
    return $this->load->view('extension/payment/glomo', $data);
  }

    public function initiatTrans()
    {
      $this->language->load('extension/payment/glomo');
      $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($this->session->data['order_id']);
    $data['action'] =$this->url->link('extension/payment/glomo');
        $data=[
            'numero'=>$this->request->post['number'],
            'amount'=>$order_info['total'],
            'title'=>$this->request->post['title'],
        ];
        $param['heard']=[
            'App-Id: '.$this->config->get('payment_glomo_api_key'),
            'App-Secret:'.$this->config->get('payment_glomo_api_secret'),
            'Authorisation: Bearer '.$this->config->get('payment_glomo_api_token'),
            'Content-Type: application/json',
            'Accept: application/json',
        ];
        $param['option']=self::API_URL.self::API_INI;
        $reponse=$this->request($data,$param);
        switch ($reponse->status) {
            case 'OK':
                $this->session->data['key'] =$reponse->cle_operation;
                break;
            
            default:
                # code...
                break;
        }
        $reponse->url=$this->url->link('extension/payment/glomo/resendsms');
        echo json_encode($reponse);

    }
    public function validerPayment()
    {
      if (isset($this->session->data['order_id'])) {
        $order_id = $this->session->data['order_id'];
      } else {
        $order_id = 0;
      }
        $data=[
            'key'=>$this->request->post['key'],
            'code_app'=>$this->request->post['code_app'],
            'code_sms'=>$this->request->post['code_sms'],
        ];
        $param['heard']=[
          'App-Id: '.$this->config->get('payment_glomo_api_key'),
          'App-Secret:'.$this->config->get('payment_glomo_api_secret'),
          'Authorisation: Bearer '.$this->config->get('payment_glomo_api_token'),
          'Content-Type: application/json',
          'Accept: application/json',
      ];
        $param['option']=self::API_URL.self::API_VALIDER;
        $reponse=$this->request($data,$param);
        $this->load->model('checkout/order');
        $order_info = $this->model_checkout_order->getOrder($order_id);
          if ($order_info) {
            $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('config_order_status_id'));

          }
        switch ($reponse->status) {
            case 'OK':
              $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_glomo_completed_status_id'), "Payment receive", true);
              $reponse->redirect=$this->url->link('account/order/info&order_id='.$order_id);
              $this->cart->clear();
                break;
            
            default:
            $this->model_checkout_order->addOrderHistory($order_id, $this->config->get('payment_glomo_failed_status_id'), "Payment Fail", true);
                break;
        }
        echo json_encode($reponse);
    }
    
    public function resendSms()
    {
       
        $data=[
            'key'=>$this->request->post['key'],
        ];
        $param['heard']=[
          'App-Id: '.$this->config->get('payment_glomo_api_key'),
          'App-Secret:'.$this->config->get('payment_glomo_api_secret'),
          'Authorisation: Bearer '.$this->config->get('payment_glomo_api_token'),
          'Content-Type: application/json',
          'Accept: application/json',
      ];
        $param['option']=self::API_URL.self::API_RESEND;
        $reponse=$this->request($data,$param);
       
        echo json_encode($reponse);
    }
    public function request($data,$param)
    {
        $url=$param['option'];
        // in this example, POST request was made using PHP's CURL
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $param['heard']);
        curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, false);
        $response = curl_exec($ch);
        $err = curl_error($ch);
        curl_close($ch);
        return json_decode($response);
    }
  private function _language($lang_id) {
    $lang = substr($lang_id, 0, 2);
    $lang = strtolower($lang);
    return $lang;
  }
}
