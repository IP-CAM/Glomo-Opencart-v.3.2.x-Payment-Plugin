## Glomo Money Opencart

[English version](#Glomo-Money-module)

### Installation

* Backup your webstore and database
* Upload the module file [opencart-glomo2.9.ocmod.zip](https://github.com/glomomoney/glomomoney-opencart/raw/master/opencart-glomo2.9.ocmod.zip) via _Extensions_ -> _Extension Installer_
* Activate the module in payment extensions (_Extensions_ -> _Payments_)
* Configure the module settings:
  * Shop App Id
  * Shop secret key
  * Shop token 
  * Payment page domain
  * Order statuses for successfuly processed payment and for failed one
  * Enabled the module
  * And optionally setup sort order id if you want to move the payment
    option higher level in payment method list